#include <stdlib.h>
#include <stdio.h>

int main() {
    for (int i=0; i<100; i++){
      printf("%d\n", 1+rand());
    }	
    return 0;
}
